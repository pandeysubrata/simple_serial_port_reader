from cx_Freeze import setup, Executable

build_exe_options = {
    "packages": [
        "serial",
        "serial.tools.list_ports",
        "threading",
        "collections",
        "datetime",
    ],
    "includes": ["tkinter", "tkinter.ttk", "tkinter.filedialog", "tkinter.messagebox"],
    "include_files": [
        "icon.ico"
    ],  # Replace path_to_icon.ico with the actual path to your icon file
}

setup(
    name="Simple Serial Port Reader",
    version="1.0",
    description="Read from serial port and write to serial port",
    options={"build_exe": build_exe_options},
    executables=[Executable("simple.py", icon="icon.ico")],
)
