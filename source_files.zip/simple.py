import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import serial.tools.list_ports
import serial
import threading
from collections import deque
from datetime import datetime


class SerialGUI:
    def __init__(self, master):
        self.master = master
        master.title("Simple Serial Port Reader by Subrata Pandey")
        master.attributes("-fullscreen", False)
        master.bind("<Escape>", lambda event: master.attributes("-fullscreen", False))

        # Variables
        self.com_port_var = tk.StringVar()
        self.baud_rate_var = tk.IntVar(value=9600)
        self.data_bits_var = tk.IntVar(value=8)
        self.stop_bits_var = tk.StringVar(value="1")
        self.parity_var = tk.StringVar(value="None")
        self.decode_var = tk.StringVar(value="ASCII")
        self.connection_status = tk.StringVar(value="Connect")
        self.status_queue = deque(maxlen=5)
        self.log_file_path = None
        self.logging_enabled = False
        self.add_cr_var = tk.BooleanVar(value=False)
        self.add_lf_var = tk.BooleanVar(value=False)

        # Serial Connection Frame
        serial_frame = ttk.LabelFrame(master, text="Serial Connection")
        serial_frame.grid(row=0, column=0, padx=10, pady=10, sticky=tk.W + tk.E)

        # COM Port Dropdown
        com_label = ttk.Label(serial_frame, text="COM Port:")
        com_label.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)

        com_combobox = ttk.Combobox(
            serial_frame, textvariable=self.com_port_var, state="readonly"
        )
        com_combobox.grid(row=0, column=1, padx=5, pady=5)

        ports = self.scan_serial_ports()
        if ports:
            com_combobox["values"] = ports
            com_combobox.current(0)
        else:
            com_combobox["values"] = ["No ports available"]
            com_combobox.current(0)

        # Baud Rate Dropdown
        baud_label = ttk.Label(serial_frame, text="Baud Rate:")
        baud_label.grid(row=0, column=2, padx=5, pady=5, sticky=tk.W)

        baud_combobox = ttk.Combobox(
            serial_frame, textvariable=self.baud_rate_var, state="readonly"
        )
        baud_combobox.grid(row=0, column=3, padx=5, pady=5)
        baud_combobox["values"] = [
            300,
            1200,
            2400,
            4800,
            9600,
            19200,
            38400,
            57600,
            115200,
        ]
        baud_combobox.current(4)  # Default to 9600

        # Data Bits Dropdown
        data_bits_label = ttk.Label(serial_frame, text="Data Bits:")
        data_bits_label.grid(row=0, column=4, padx=5, pady=5, sticky=tk.W)

        data_bits_combobox = ttk.Combobox(
            serial_frame, textvariable=self.data_bits_var, state="readonly"
        )
        data_bits_combobox.grid(row=0, column=5, padx=5, pady=5)
        data_bits_combobox["values"] = [5, 6, 7, 8]
        data_bits_combobox.current(3)  # Default to 8

        # Stop Bits
        stop_bits_label = ttk.Label(serial_frame, text="Stop Bits:")
        stop_bits_label.grid(row=0, column=6, padx=5, pady=5, sticky=tk.W)

        stop_bits_combobox = ttk.Combobox(
            serial_frame, textvariable=self.stop_bits_var, state="readonly"
        )
        stop_bits_combobox.grid(row=0, column=7, padx=5, pady=5)
        stop_bits_combobox["values"] = ["1", "1.5", "2"]
        stop_bits_combobox.current(0)

        # Parity
        parity_label = ttk.Label(serial_frame, text="Parity:")
        parity_label.grid(row=0, column=8, padx=5, pady=5, sticky=tk.W)

        parity_combobox = ttk.Combobox(
            serial_frame, textvariable=self.parity_var, state="readonly"
        )
        parity_combobox.grid(row=0, column=9, padx=5, pady=5)
        parity_combobox["values"] = ["None", "Even", "Odd"]
        parity_combobox.current(0)

        # Decode Dropdown
        decode_label = ttk.Label(serial_frame, text="Decode:")
        decode_label.grid(row=0, column=10, padx=5, pady=5, sticky=tk.W)

        decode_combobox = ttk.Combobox(
            serial_frame, textvariable=self.decode_var, state="readonly"
        )
        decode_combobox.grid(row=0, column=11, padx=5, pady=5)
        decode_combobox["values"] = ["ASCII", "Hex", "Binary"]
        decode_combobox.current(0)

        # Checkbox for CR and LF
        cr_checkbox = ttk.Checkbutton(master, text="Add CR", variable=self.add_cr_var)
        cr_checkbox.grid(row=5, column=0, padx=10, pady=5, sticky=tk.EW)

        lf_checkbox = ttk.Checkbutton(master, text="Add LF", variable=self.add_lf_var)
        lf_checkbox.grid(row=6, column=0, padx=10, pady=5, sticky=tk.NSEW)

        # Buttons
        self.connect_button = ttk.Button(
            master, textvariable=self.connection_status, command=self.toggle_connection
        )
        self.connect_button.grid(row=1, column=0, padx=10, pady=5)

        send_button = ttk.Button(master, text="Send", command=self.send_data)
        send_button.grid(row=4, column=0, padx=10, pady=5)

        start_logging_button = ttk.Button(
            master, text="Start Logging", command=self.start_logging
        )
        start_logging_button.grid(row=10, column=0, padx=10, pady=5)

        stop_logging_button = ttk.Button(
            master, text="Stop Logging", command=self.stop_logging
        )
        stop_logging_button.grid(row=11, column=0, padx=10, pady=5)

        # Text Areas
        incoming_frame = ttk.LabelFrame(master, text="Incoming Data")
        incoming_frame.grid(row=2, column=0, padx=10, pady=10, sticky=tk.W + tk.E)
        self.incoming_text = tk.Text(
            incoming_frame, height=13, width=165, wrap="word", state="normal"
        )
        self.incoming_text.grid(row=0, column=0, padx=5, pady=5)
        incoming_scroll = ttk.Scrollbar(
            incoming_frame, orient=tk.VERTICAL, command=self.incoming_text.yview
        )
        incoming_scroll.grid(row=0, column=1, sticky=tk.NS)
        self.incoming_text.config(yscrollcommand=incoming_scroll.set)

        send_frame = ttk.LabelFrame(master, text="Data to Send")
        send_frame.grid(row=3, column=0, padx=10, pady=10, sticky=tk.W + tk.E)
        self.send_text = tk.Text(
            send_frame, height=2, width=165, wrap="word", state="normal"
        )
        self.send_text.grid(row=0, column=0, padx=5, pady=5)
        send_scroll = ttk.Scrollbar(
            send_frame, orient=tk.VERTICAL, command=self.send_text.yview
        )
        send_scroll.grid(row=0, column=1, sticky=tk.NS)
        self.send_text.config(yscrollcommand=send_scroll.set)

        status_frame = ttk.LabelFrame(master, text="Status")
        status_frame.grid(row=9, column=0, padx=10, pady=10, sticky=tk.W + tk.E)
        self.status_text = tk.Text(
            status_frame, height=2, width=165, wrap="word", state="normal"
        )
        self.status_text.grid(row=0, column=0, padx=5, pady=5)
        status_scroll = ttk.Scrollbar(
            status_frame, orient=tk.VERTICAL, command=self.status_text.yview
        )
        status_scroll.grid(row=0, column=1, sticky=tk.NS)
        self.status_text.config(yscrollcommand=status_scroll.set)
        self.status_text.tag_configure("status", foreground="blue")
        # Copyright Label
        copyright_label = ttk.Label(
            master,
            text="\u00A9 Copyright protected by Subrata Pandey v0.0",
            foreground="gray",
        )
        copyright_label.grid(row=13, column=0, padx=10, pady=5)

        # Serial Connection Object
        self.ser = None

    def scan_serial_ports(self):
        """Scan for available serial ports."""
        ports = serial.tools.list_ports.comports()
        return [port.device for port in ports]

    def toggle_connection(self):
        """Toggle connection to the selected serial port."""
        if self.ser and self.ser.is_open:
            self.disconnect()
        else:
            self.connect()

    def connect(self):
        """Connect to the selected serial port."""
        try:
            self.ser = serial.Serial(
                port=self.com_port_var.get(),
                baudrate=self.baud_rate_var.get(),
                bytesize=self.data_bits_var.get(),
                stopbits=float(self.stop_bits_var.get()),
                parity=self.get_parity_value(),
                timeout=0.1,
            )
            self.status_text.insert(
                "1.0", "Connected to {}\n".format(self.com_port_var.get())
            )
            self.connection_status.set("Disconnect")
            self.start_reading()
        except serial.SerialException as e:
            self.status_text.insert("1.0", "Failed to connect: {}\n".format(str(e)))

    def disconnect(self):
        """Disconnect from the serial port."""
        if self.ser and self.ser.is_open:
            self.ser.close()
            self.ser = None
            self.status_text.insert(
                "1.0", "Disconnected from {}\n".format(self.com_port_var.get())
            )
            self.connection_status.set("Connect")

    def get_parity_value(self):
        """Get parity value based on selected option."""
        parity = self.parity_var.get()
        if parity == "None":
            return serial.PARITY_NONE
        elif parity == "Even":
            return serial.PARITY_EVEN
        elif parity == "Odd":
            return serial.PARITY_ODD

    def send_data(self):
        """Send data over the serial connection."""
        if self.ser and self.ser.is_open:
            data = self.send_text.get(
                "1.0", tk.END
            ).strip()  # Get text from send text area
            if data:
                if self.add_cr_var.get():
                    data += "\r"
                if self.add_lf_var.get():
                    data += "\n"
                encoding_method = self.decode_var.get()
                if encoding_method == "ASCII":
                    self.ser.write(data.encode())
                elif encoding_method == "Hex":
                    try:
                        hex_data = bytes.fromhex(data)
                        self.ser.write(hex_data)
                    except ValueError:
                        self.status_text.insert("1.0", "Invalid hexadecimal format!\n")
                        return
                self.status_text.insert("1.0", "Sent: {}\n".format(data))
            else:
                self.status_text.insert("1.0", "No data to send!\n")
        else:
            self.status_text.insert("1.0", "Not connected to any serial port!\n")

    def start_reading(self):
        """Start reading data from serial port."""
        if self.ser and self.ser.is_open:
            self.read_thread = threading.Thread(target=self.read_data)
            self.read_thread.daemon = True
            self.read_thread.start()

    def read_data(self):

        while self.ser and self.ser.is_open:
            try:
                data = self.ser.read(1024)
                print("Received data:", data)  # Add this line to check received data
                if data:
                    decoded_data = self.decode_data(data)
                    self.incoming_text.insert(tk.END, decoded_data + "\n")
                    if self.logging_enabled:
                        self.log_data(decoded_data)
            except serial.SerialException as e:
                self.status_text.insert(
                    "1.0", "Error reading data: {}\n".format(str(e))
                )

    def decode_data(self, data):
        """Decode the received data based on the selected decoding method."""
        encoding_method = self.decode_var.get()
        if encoding_method == "ASCII":
            return data.decode("ascii")
        elif encoding_method == "Hex":
            return data.hex()
        elif encoding_method == "Binary":
            return " ".join(format(byte, "08b") for byte in data)

    def log_data(self, data):
        """Log incoming data to a text file with timestamp."""
        if self.log_file_path:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            with open(self.log_file_path, "a") as f:
                f.write("[{}] {}\n".format(timestamp, data))

    def start_logging(self):
        """Start logging incoming data."""
        self.log_file_path = filedialog.asksaveasfilename(
            title="Select log file",
            defaultextension=".log",
            filetypes=[
                ("Text Files", "*.txt"),
                ("Log Files", "*.log"),
                ("All Files", "*.*"),
            ],
        )
        if self.log_file_path:
            self.logging_enabled = True
            self.status_text.insert(
                "1.0", "Logging enabled. Log file: {}\n".format(self.log_file_path)
            )

    def stop_logging(self):
        """Stop logging incoming data."""
        self.logging_enabled = False
        self.status_text.insert("1.0", "Logging stopped.\n")

    def update_status(self, message):
        """Update status information."""
        self.status_queue.appendleft(message)
        self.status_text.config(state="normal")
        self.status_text.delete("1.0", tk.END)
        for status in self.status_queue:
            self.status_text.insert("1.0", status + "\n", "status")
        self.status_text.config(state="disabled")


def main():
    root = tk.Tk()
    app = SerialGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
